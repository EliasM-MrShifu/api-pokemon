// Server.js

import express from 'express'
import cors from 'cors'
import mysql from 'mysql2'

const app = express()

// 🔌 Configuración de la Conexión MySQL
const db = mysql.createConnection({
  host: '127.0.0.1', // ⬅️ Mejor usar la IP local en lugar de 'localhost'
  user: 'root',
  password: '', // ⚠️ ¡Cuidado con dejar la contraseña vacía en producción!
  database: 'pokedex' 
})

// 🌐 Middlewares
app.use(cors()) // Permite la comunicación entre Vue (diferente puerto) y este servidor
app.use(express.json()) // Reemplaza a body-parser, lee datos JSON del frontend

db.connect(err => {
  if (err) {
    console.error('❌ Error de conexión a MySQL:', err)
  } else {
    console.log('✅ Conectado a MySQL.')
  }
})

// 🔹 POST: guardar equipo (Guarda el equipo en SQL)
app.post('/equipos', (req, res) => {
  console.log('--- Petición POST /equipos RECIBIDA ---')
  
  const { nombre, pokemones } = req.body

  if (!nombre || !pokemones) {
    return res.status(400).json({ error: 'Faltan datos de nombre o pokemones' })
  }
  
  // 💡 El array de JS se convierte a string JSON antes de insertar en MySQL
  const sql = 'INSERT INTO equipos (nombre, pokemones) VALUES (?, ?)'
  
  db.query(sql, [nombre, JSON.stringify(pokemones)], (err, result) => {
    if (err) {
      console.error('❌ Error al insertar:', err)
      return res.status(500).json({ error: 'Error al guardar el equipo en la base de datos' })
    }

    console.log(`✅ Equipo "${nombre}" guardado correctamente. ID: ${result.insertId}`)
    res.json({ mensaje: 'Equipo guardado correctamente', id: result.insertId })
  })
})

// 🔹 GET: obtener todos los equipos (Lee los equipos desde SQL)
app.get('/listado', (req, res) => {
  console.log('--- Petición GET /listado RECIBIDA ---')

  db.query('SELECT * FROM equipos', (err, results) => {
    if (err) {
      console.error('❌ Error al obtener equipos:', err)
      return res.status(500).json({ success: false, error: err })
    }

    res.json({ success: true, equipos: results })
  })
})

// 🚀 Servidor en puerto 3001
app.listen(3001, () => {
  console.log('🚀 Servidor corriendo en http://localhost:3001')
})
import express from 'express'
import cors from 'cors'
import mysql from 'mysql2'

const app = express()
app.use(cors())
app.use(express.json())


const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'pokedex'
})

db.connect(err => {
    if (err) {
        console.error('❌ Error de conexión a MySQL:', err)
    } else {
        console.log('✅ Conectado a MySQL.')
    }
})

// --- 🚀 ENDPOINT: Guardar Nuevo Equipo (POST /equipos) ---
// Recibe: { nombre: "Mi Equipo", pokemones: [ID1, ID2, ID3] }
app.post('/equipos', (req, res) => {
    // pokemones es un array de IDs, como [4, 7, 25], enviado desde Vue.
    const { nombre, pokemones } = req.body

    if (!nombre || !pokemones || pokemones.length === 0) {
        return res.status(400).json({ error: 'Faltan el nombre o la lista de IDs de Pokémones.' })
    }

    // 1. Inserción del Equipo principal
    // Nota: Eliminamos la columna 'pokemones' de esta inserción
    const sqlEquipo = 'INSERT INTO equipos (nombre, fecha_creacion) VALUES (?, NOW())'
    db.query(sqlEquipo, [nombre], (err, resultEquipo) => {
        if (err) {
            console.error('❌ Error al insertar el equipo:', err)
            return res.status(500).json({ error: 'Error al guardar el equipo principal.', dbError: err.sqlMessage })
        }

        const equipoId = resultEquipo.insertId

        // 2. Preparar los datos para la tabla intermedia (equipo_pokemon)
        // Crea un array de arrays: [[equipoId, pokemonId1], [equipoId, pokemonId2], ...]
        const values = pokemones.map(pokemonId => [equipoId, pokemonId])

        // 3. Inserción en la tabla intermedia
        // El signo de interrogación "?" es reemplazado por el array 'values'
        const sqlRelacion = 'INSERT INTO equipo_pokemon (equipo_id, pokemon_id) VALUES ?'
        db.query(sqlRelacion, [values], (errRelacion) => {
            if (errRelacion) {
                console.error('❌ Error al insertar las relaciones de Pokémones:', errRelacion)
                // Se recomienda un rollback aquí en un entorno de producción para borrar el equipo recién creado
                return res.status(500).json({ error: 'Error al guardar los Pokémones del equipo.', dbError: errRelacion.sqlMessage })
            }

            console.log(`✅ Equipo "${nombre}" (ID: ${equipoId}) guardado con ${pokemones.length} Pokémones.`)
            res.json({ mensaje: 'Equipo guardado correctamente', id: equipoId })
        })
    })
})


// --- 🚀 ENDPOINT: Obtener Listado de Equipos (GET /listado) ---
// Utiliza JOIN para obtener todos los Pokémones asociados y GROUP_CONCAT para agruparlos en un objeto JSON.
app.get('/listado', (req, res) => {
    const sql = `
        SELECT
            e.id,
            e.nombre,
            e.fecha_creacion,
            -- Agrupa los datos del Pokémon en una cadena JSON
            GROUP_CONCAT(
                JSON_OBJECT('id', p.id, 'name', p.name, 'image', p.image)
            ) AS pokemones_json
        FROM
            equipos e
        JOIN
            equipo_pokemon ep ON e.id = ep.equipo_id
        JOIN
            pokemones p ON ep.pokemon_id = p.id
        GROUP BY
            e.id, e.nombre, e.fecha_creacion
        ORDER BY 
            e.fecha_creacion DESC;
    `;

    db.query(sql, (err, results) => {
        if (err) {
            console.error('❌ Error al obtener equipos:', err)
            return res.status(500).json({ success: false, error: err })
        }

        // Post-procesamiento para convertir la cadena JSON agrupada en un array JavaScript
        const equiposFormateados = results.map(equipo => ({
            id: equipo.id,
            nombre: equipo.nombre,
            fecha_creacion: equipo.fecha_creacion,
            // Convertimos la cadena del GROUP_CONCAT en un array de objetos JavaScript.
            pokemones: JSON.parse(`[${equipo.pokemones_json}]`)
        }))

        res.json({ success: true, equipos: equiposFormateados })
    })
})

app.listen(3001, () => {
    console.log('🚀 Servidor corriendo en http://localhost:3001')
})
<script setup>
import { computed, ref, onMounted } from 'vue'
import { usePokemonStore } from '@/stores/PokemonPinia.js'
import axios from '@/api/axios'

const store = usePokemonStore()
const equipoSeleccionado = computed(() => store.seleccionados)
const nombreEquipo = ref('Mi equipo Pokémon')
const nuevoNombre = ref(nombreEquipo.value)

// Lista para los equipos de la base de datos
const equiposGuardados = ref([])

// Cargar equipos del servidor
async function cargarHistorial() {
    try {
        const respuesta = await axios.get('/listado')

        // 💡 CORRECCIÓN: Si el backend (endpoint /listado) ya hace el JOIN y GROUP_CONCAT,
        // los datos de los pokemones deberían venir ya formateados como un array de objetos.
        equiposGuardados.value = respuesta.data.equipos
    } catch (err) {
        console.error("Error al cargar:", err)
    }
}

onMounted(cargarHistorial)

const guardarEquipoSQL = async () => {
    if (equipoSeleccionado.value.length === 0) {
        return alert("Equipo vacío. Selecciona al menos un Pokémon.")
    }

    // 💡 CORRECCIÓN CRÍTICA: Mapeamos los objetos Pokémon completos a un array de solo IDs.
    // Esto es lo que el backend espera ahora para insertar en la tabla intermedia.
    const pokemonIds = equipoSeleccionado.value.map(p => p.id)

    try {
        await axios.post("/equipos", {
            nombre: nombreEquipo.value,
            pokemones: pokemonIds // Enviamos solo los IDs
        })
        alert("¡Guardado exitoso!")
        cargarHistorial() // Recarga la lista
    } catch (err) {
        console.error("Error al guardar:", err)
        alert("Error al guardar el equipo. Revisa la consola para más detalles.")
    }
}
</script>

<template>
    <div style="padding: 20px; font-family: sans-serif;">

        <h1>{{ nombreEquipo }}</h1>
        <input v-model="nuevoNombre" placeholder="Cambiar nombre" />
        <button @click="nombreEquipo = nuevoNombre">Renombrar</button>

        <div v-if="equipoSeleccionado.length > 0">
            <div style="display: flex; gap: 10px; margin: 20px 0;">
                <div v-for="p in equipoSeleccionado" :key="p.id"
                    style="border: 1px solid #ccc; padding: 10px; text-align: center;">
                    <img :src="p.image" width="60" :alt="p.name" />
                    <p>{{ p.name }}</p>
                    <button @click="store.removerPokemon(p)">X</button>
                </div>
            </div>
            <button @click="guardarEquipoSQL" style="background: green; color: white; padding: 10px; border: none; cursor: pointer;">
                Guardar este equipo
            </button>
        </div>
        <p v-else>No has seleccionado Pokémon aún.</p>

        <hr style="margin: 40px 0;" />

        <h2>Equipos en la Base de Datos</h2>
        <div v-for="equipo in equiposGuardados" :key="equipo.id"
            style="background: #f4f4f4; padding: 15px; margin-bottom: 10px; border-radius: 8px;">
            <strong style="font-size: 1.2rem;">{{ equipo.nombre }}</strong>
            <div style="display: flex; gap: 15px; margin-top: 10px;">
                <div v-for="p in equipo.pokemones" :key="p.id" style="font-size: 0.8rem; text-align: center;">
                    <img :src="p.image" width="40" :alt="p.name" /><br>
                    {{ p.name }}
                </div>
            </div>
        </div>

    </div>
</template>

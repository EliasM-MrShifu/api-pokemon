  <script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { usePokemonStore } from '@/stores/PokemonPinia'
import { useRouter } from 'vue-router'

const listado = ref([])
const store = usePokemonStore()
const router = useRouter()

async function obtenerPokemons() {
  const respuesta = await axios.get('https://pokeapi.co/api/v2/pokemon?limit=151')
  listado.value = respuesta.data.results.map((pokemon, index) => ({
    id: index + 1,
    name: pokemon.name,
    image: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${index + 1}.png`
  }))
}
onMounted(obtenerPokemons)

function elegir(pokemon) {
  store.elegirPokemon(pokemon)
}
</script>

<template>
  <div class="listado">
    <div class="grid">
      <div v-for="p in listado" :key="p.id" class="card">
        <img :src="p.image" :alt="p.name" />
        <p>{{ p.name }}</p>
        <button @click="elegir(p)">Elegir</button>
      </div>
    </div>

    <button class="ver-equipo" @click="router.push('/pokemon/equipo')">
      Ver Mi Equipo
    </button>
  </div>
</template>

<style scoped>
.listado {
  text-align: center;
  padding: 1rem;
  color: white;
  background: #dd5127;
  min-height: 100vh;
}

.grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
  gap: 1rem;
}

.card {
  background: white;
  color: black;
  border-radius: 8px;
  padding: 1rem;
}



.ver-equipo {
  margin-top: 1.5rem;
  background: #007bff;
}
</style>

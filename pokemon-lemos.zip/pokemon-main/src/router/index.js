import { createRouter, createWebHistory } from 'vue-router'
import ListadoDePokemons from '@/views/ListadoDePokemons.vue'
import PokemonDetalle from '@/views/PokemonDetalle.vue'



const routes = [
  { path: '/listado',
    name: 'listado',
    component: ListadoDePokemons },

  { path: '/pokemon',
  name: 'detalle',
  component: PokemonDetalle }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router



<script setup>
import { RouterView, RouterLink } from 'vue-router'


</script>

<template>
  <router-link to="/equipos-guardados" class="btn-link">
    Ver Equipos Guardados
</router-link>
  <header>
    <nav>
      <RouterLink to="/listado">Listado pokemon</RouterLink>
      <RouterLink to="/pokemon">Tu equipo</RouterLink>
    </nav>
  </header>

  <RouterView />
</template>

<style scoped>
header {
  text-align: center;
  padding: 1rem;
  background: #dd5127;
}

nav a {
  color: white;
  text-decoration: none;
  margin: 0 1rem;
  font-weight: bold;
}

nav a {
  text-decoration: underline;
}
</style>
